user=$(whoami)
if [ "$user" != "root" ]
then
    echo "Root privileges are required for installation."
    exit 1
fi
echo "Installing ..."
mkdir -p /opt/cine
mkdir -p /opt/cine/modules
cp -f -r ./standart /opt/cine/modules/standart
./fei-x86_64 install cine.fpkg
./fei-x86_64 install fei.fpkg
chown -R root:root /opt/cine
echo "Done."
